import type React from "react";
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse } from "axios";

export interface ServiceConfig {
  name: string;
  baseURL: string;
  timeout?: number;
  headers?: Record<string, string>;
}

export interface AxiosContextType {
  // Get axios instance for a specific service
  getAxiosInstance: (serviceName: string) => AxiosInstance;

  addService: (config: ServiceConfig) => void;
  removeService: (serviceName: string) => void;
  getServices: () => ServiceConfig[];

  // Request interceptors
  addRequestInterceptor: (
    onFulfilled?: (config: AxiosRequestConfig) => AxiosRequestConfig,
    onRejected?: (error: any) => any,
  ) => number;

  // Response interceptors
  addResponseInterceptor: (
    onFulfilled?: (response: AxiosResponse) => AxiosResponse,
    onRejected?: (error: any) => any,
  ) => number;
}

export interface AxiosProviderProps {
  children: React.ReactNode;
  services?: ServiceConfig[];
  defaultTimeout?: number;
  onUnauthorized?: () => void;
  onTokenRefresh?: () => Promise<string | null>;
}

export interface RequestConfig extends AxiosRequestConfig {
  skipAuth?: boolean;
  retryOnUnauthorized?: boolean;
}
