import type { ServiceConfig } from "./axios.type";

// Default service configurations
export const DEFAULT_SERVICES: ServiceConfig[] = [
  {
    name: "auth",
    baseURL: "https://auth.test.com",
    timeout: 10000,
  },
  {
    name: "user",
    baseURL: "https://user.test.com",
    timeout: 10000,
  },
  {
    name: "api",
    baseURL: "https://api.test.com",
    timeout: 15000,
  },
];

// Default headers
export const DEFAULT_HEADERS = {
  "Content-Type": "application/json",
  Accept: "application/json",
};

export const DEFAULT_TIMEOUT = 10000;

// Retry configuration
export const RETRY_CONFIG = {
  maxRetries: 3,
  retryDelay: 1000,
  retryOn401: true,
};
